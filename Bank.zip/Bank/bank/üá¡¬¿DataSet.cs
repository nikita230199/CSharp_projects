﻿namespace bank {
    
    
    public partial class БанкиDataSet {
    }
}
