﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ИС_Книжный_магазин
{
    class Operator
    {
        //public int Index { get; set; }
        //public string Name { get; set; }

        //public Operator() { }

        //public Operator(int i, string n)
        //{
        //    Index = i;
        //    Name = n;
        //}
    }
}
